module.exports = {
   bracketSpacing: false,
   jsxBracketSameLine: false,
   singleQuote: true,
   trailingComma: 'all',
};
