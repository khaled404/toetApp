export default {
  BackgroundColor: '#F5F6F8',
  MainColor: '#5A64A8',
  ColorScandre: '#61AA61',
  FontFamily: 'Tajawal',
  FontFamilyBold: 'Tajawal-bold',
  RegularFontSize: '15',
};
