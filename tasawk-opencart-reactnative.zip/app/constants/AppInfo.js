//export const BASEURI = "http://someotherhost.com/opencartapi/index.php?route=";
export const BASEURI = 'https://toet.com/api/index.php?route=';
export const LIVECHAT_LICENSE = '11547483';
export const TWITTER_COMSUMER_KEY = 'xpZLLYS63ka4Cn7xEKuZDDX1y';
export const TWITTER_CONSUMER_SECRET =
  'xGRGgCMLRYjoRoCm1qNYw8HiE02xmJVonvxffDEiwrjZAmwbaU';
