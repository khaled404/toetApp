module.exports = {
    project: {
        android: {}
    },
    assets: ['./assets/fonts/'],
};